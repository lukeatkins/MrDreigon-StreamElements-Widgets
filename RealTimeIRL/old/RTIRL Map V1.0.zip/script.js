
class DreigonWidget {

    constructor() {
        this.config = null;
        this.channel = null;
        this.channelId = null;
        this.token = null;
        this.storeKey = "dreigon-rtirl"
        this.commands = {
        };

        this.init();
    }

    init() {
        window.addEventListener('onEventReceived', this.onEvent.bind(this));
        window.addEventListener('onWidgetLoad', (obj) => {
            console.log(JSON.stringify(obj.detail.channel));
            this.channel = obj.detail.channel.username;
            this.channelId = obj.detail.channel.id;
            this.config = obj.detail.fieldData;
            this.token = this.config.jebaitedToken;
            this.loadState();
            this.start();
        });

    }

    start() {
        var container = document.getElementById("map");
        this.map = L.map(container, {
            attributionControl: false,
            zoomControl: false,
            dragging: false,
        }).setView([0, 0], this.config.mapZoom);
		this.tileLayer = L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
                zoom: this.config.mapZoom,
            }
        );
        this.tileLayer.addTo(this.map);
		this.tileLayer.on("tileerror", err => {
			console.log("Tile Error: ", err);
		});
		var icon = `https://earth.google.com/earth/rpc/cc/icon?color=943bf9&id=2000&scale=4`;//fallback
		if (this.config.googleEarthIcon == "custom") {
			if (this.config.iconURL) icon = this.config.iconURL;
		} else {
			var id = this.config.googleEarthIcon;
			if (id == "other") id = this.config.googleEarthIconOther;
			console.log("Pin Color: ", this.config.googleEarthIconColor);
			icon = `https://earth.google.com/earth/rpc/cc/icon?color=${this.config.googleEarthIconColor.substring(1)}&id=${id}&scale=2`;
		}
		var scale = this.config.iconScale ?? 1;
		this.gpsPin = L.marker([0,0], {
			icon: L.icon({
				iconUrl: icon,
				iconSize: [64*scale,64*scale],
				iconAnchor: [32*scale,64*scale]
			})
		});
		this.gpsPin.addTo(this.map);

        const pullKey = this.config.rtIRLAPIKey;
        if (pullKey) {
			this.rtirlAPI = new RTIRLAPI(pullKey);
			this.rtirlAPI.start();
			this.rtirlAPI.on("location", loc => {
				console.log("New Location:",loc);
				var coord = L.latLng(loc.latitude, loc.longitude);
				this.gpsPin.setLatLng(coord);
				this.map.panTo(coord, {duration: 1.5});
			});
        }
		// setTimeout(() => this.map.invalidateSize(), 2000);
    }

    onEvent(evt) {
        const listener = evt.detail.listener;
        if (evt.detail.event) {
            if (evt.detail.event.listener === 'widget-button') {
                var id = evt.detail.event.field;
                this.onWidgetButton(id);                
                return;
            }
        }
    
        if (listener.endsWith("-latest")) {
            const data = evt.detail.event;
            switch (listener) {
                case "follower-latest":
                    this.onFollower(data);
                    return;
                case "subscriber-latest":
                    if (data.bulkGifted) return; // Ignore gifting event and count only real subs
                    var tier = parseInt(data.tier);
                    switch (tier) {
                        default:
                            this.onTier1Sub(data);
                            return;
                        case 2000:
                            this.onTier2Sub(data);
                            return;
                        case 3000:
                            this.onTier3Sub(data);
                            return;
                    }
                    return;
                case "host-latest":
                    this.onHostEvent(data);
                    return;
                case "raid-latest":
                    this.onRaidEvent(data);
                    return;
                case "cheer-latest":
                    this.onCheerEvent(data);
                    return;
                case "tip-latest":
                    this.onTipEvent(data);
                    return;
            }
        }

        switch(listener) {
            case "message":
                this.handleMessage(evt.detail.event.data);
                break;
        }
    }

    onWidgetButton(id) {
       switch (id) {

       }
    }
    
    onFollower(data) {
    }

    onTier1Sub(data) {        
    }

    onTier2Sub(data) {        
    }

    onTier3Sub(data) {        
    }

    onHostEvent(data) {
    }

    onRaidEvent(data) {
    }

    onCheerEvent(data) {
    }

    onTipEvent(data) {
    }

    serialize() {
        return {
            
        };
    }

    deserialize(data) {

    }

    saveState() {
        SE_API.store.set(this.storeKey, this.serialize());
    }
    
    loadState() {
        SE_API.store.get(this.storeKey).then(obj => {
            this.deserialize();
        })
        .catch(err => {
            this.saveState();
        });
    }

    handleMessage(evt) {
        var userState = { mod: parseInt(evt.tags.mod), broadcaster: evt.nick === this.channel };
        if (!(userState.mod == 1 || userState.broadcaster)) return;
        var msg = evt.text;
        if (!msg.startsWith("!")) return;
        var args = msg.substring(1).split(" ");
        var cmd = args.shift().toLowerCase();

        for (var key in this.commands) {
            if (key.toLocaleLowerCase() === cmd.toLocaleLowerCase()) {
                this.commands[key](...args);
            }
        }
    }

    sendMessage(msg) {
        if (!this.token) return;
        fetch(`https://api.jebaited.net/botMsg/${this.token}/${encodeURIComponent(msg.toString())}`).then(res => {
            console.log("Message Sent: ", res);
        }).catch(err => {
            console.log("Error sending message: ", err);
        });
    }

}

const RTIRLConf = {
	Namespace: "rtirl-a1d7f-default-rtdb",
	App_Id: "1:684852107701:web:d77a8ed0ee5095279a61fc",
	Version: 5,
}

class RTIRLAPI {

	constructor(pullKey) {
		this.pullKey = pullKey;
		this.requestIndex = 1;
		this.requests = [];
		this.callbacks = {};
		this.events = {
			location: [],
		};
		this.connected = false;
	}

	start() {
		this.ws = new WebSocket(`wss://s-usc1a-nss-2007.firebaseio.com/.ws?v=${RTIRLConf.Version}&p=${RTIRLConf.App_Id}&ns=${RTIRLConf.Namespace}`);
		this.ws.addEventListener("open", evt => {
			this.connected = true;
			this.sendMessage({ a: "s",	b: { c: { "sdk.js.9-8-1": 1 } } }, res => {
				console.log("SDK Version set");
				this.registerCallback(`pullables/${this.pullKey}/location`, this.onLocationEvent.bind(this), res => {
					if (this.pingLoop) clearInterval(this.pingLoop);
					this.pingLoop = setInterval(() => {
						if (this.connected) this.ws.send("0");						
					}, 30000);
				});
			});
		});
		this.ws.addEventListener("message", this.onMessage.bind(this));
		this.ws.addEventListener("close", () => {
			this.connected = false;
			console.log("Error, Web Socket Closed Unexpectedly");
			this.start();
		});
	}

	on(evtName, callback) {
		if (this.events[evtName] instanceof Array && typeof(callback) == "function") this.events[evtName].push(callback);
	}

	emit(evtName, data) {
		if (!(this.events[evtName] instanceof Array)) return;
		this.events[evtName].forEach(cb => cb(data));
	}

	onMessage(evt) {
		try {
			var res = JSON.parse(evt.data);
			var id = res.d?.r;
			var req = this.requests.findIndex(e => e.Id == id);
			if (req != -1) {
				console.log(`Response to message [${id}]: `, JSON.stringify(res.d));
				req = this.requests.splice(req, 1)[0];
				if (req.Callback) req.Callback(res.d);
			} else {
				var listener = res.d?.b?.p;
				if (listener && this.callbacks[listener]) {
					this.callbacks[listener](res.d.b);
				} else {
					console.log("Generic Response: ", JSON.stringify(res.d));
				}
			}
		} catch(err) {
			console.log(err);
		}
	}

	onLocationEvent(res) {
		var location = res.d;
		this.emit("location", location);
	}

	sendMessage(data, callback) {
		var index = this.requestIndex++;
		console.log(`Sending message [${index}]: `, JSON.stringify(data));
		var msg = {
			t: "d",
			d: {
				r: index,
				...data
			}
		};
		this.requests.push({Id: index, Callback: callback, Timestamp: Date.now()});
		if (this.connected) this.ws.send(JSON.stringify(msg));
	}

	registerCallback(listener, handler, callback) {
		this.callbacks[listener] = handler;
		this.sendMessage({ a: "q", b: { p: `/${listener}`, h: ""}}, res => {
			console.log(`Callback ${listener} registered`);
			callback(res);
		})
	}

}

const app = new DreigonWidget();
